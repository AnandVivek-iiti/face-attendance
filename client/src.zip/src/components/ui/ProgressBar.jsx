export default function ProgressBar({ value, label, indeterminate = false }) {
  const width = `${Math.round(Math.min(1, Math.max(0, value)) * 100)}%`;
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={indeterminate ? undefined : Math.round(value * 100)}
      className="h-2 w-full overflow-hidden rounded-full bg-line"
    >
      <div
        className={`h-full rounded-full bg-primary ${indeterminate ? 'w-1/3 animate-pulse' : 'transition-[width]'}`}
        style={indeterminate ? undefined : { width }}
      />
    </div>
  );
}
