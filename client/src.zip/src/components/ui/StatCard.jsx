export default function StatCard({ icon: Icon, label, value, hint, to }) {
  return (
    <div className="rounded-panel border border-line bg-white p-4">
      <div className="flex items-center gap-2 text-sm text-muted">
        {Icon && <Icon size={16} aria-hidden="true" />}
        <span>{label}</span>
      </div>
      <p className="mt-2 font-serif text-3xl font-bold tabular-nums text-ink">{value}</p>
      {hint && <p className="mt-1 truncate text-xs text-muted">{hint}</p>}
    </div>
  );
}
