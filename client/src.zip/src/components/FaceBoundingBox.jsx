import { AlertTriangle, CheckCircle2, HelpCircle } from 'lucide-react';
import { DECISION } from '../utils/constants';
import { percent } from '../utils/format';
import { faceQualityLevel } from '../utils/attendance';
import { decisionConfig } from './ConfidenceBadge';

const palette = {
  [DECISION.HIGH]: { color: '#17693f', fill: 'rgba(23,105,63,0.10)', border: 'solid', icon: CheckCircle2 },
  [DECISION.REVIEW]: { color: '#8f5200', fill: 'rgba(143,82,0,0.14)', border: 'dashed', icon: AlertTriangle },
  [DECISION.UNKNOWN]: { color: '#a8231b', fill: 'rgba(168,35,27,0.12)', border: 'dotted', icon: HelpCircle },
};

export default function FaceBoundingBox({ face, size, selected, showLabel, onSelect }) {
  const [x1, y1, x2, y2] = face.bbox;
  const style = palette[face.decision] ?? palette[DECISION.UNKNOWN];
  const Icon = style.icon;
  const label = decisionConfig(face.decision).label;
  const score = face.similarity ? percent(face.similarity) : '';
  const quality = faceQualityLevel(face.faceQuality);
  const nearTop = y1 / size.height < 0.07;
  const fullText = `${face.name}, ${label}${score ? ` ${score}` : ''}${quality ? `, face quality ${quality}` : ''}${face.dismissed ? ', ignored' : ''}`;

  return (
    <button
      type="button"
      onClick={() => onSelect(face.key)}
      aria-label={fullText}
      aria-pressed={selected}
      title={fullText}
      className="group absolute focus-visible:z-30"
      style={{
        left: `${(x1 / size.width) * 100}%`,
        top: `${(y1 / size.height) * 100}%`,
        width: `${((x2 - x1) / size.width) * 100}%`,
        height: `${((y2 - y1) / size.height) * 100}%`,
        border: `${selected ? 3 : 2}px ${style.border} ${style.color}`,
        background: style.fill,
        opacity: face.dismissed ? 0.45 : 1,
        zIndex: selected ? 20 : 10,
      }}
    >
      {(showLabel || selected) && (
        <span
          className={`absolute left-[-2px] flex max-w-[220px] items-center gap-1 whitespace-nowrap rounded-sm px-1 py-px text-[10px] font-semibold leading-tight text-white ${
            nearTop ? 'top-full mt-0.5' : 'bottom-full mb-0.5'
          }`}
          style={{ background: style.color }}
        >
          <Icon size={10} aria-hidden="true" className="shrink-0" />
          <span className="truncate">
            {selected ? face.name : face.name.split(' ')[0]}
            {score && ` ${score}`}
          </span>
          {selected && quality && <span className="shrink-0">Q: {quality}</span>}
        </span>
      )}
    </button>
  );
}
