import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Plus, Users } from 'lucide-react';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import EmptyState from '../components/ui/EmptyState';
import ErrorState from '../components/ui/ErrorState';
import { SearchInput, TextInput } from '../components/ui/Field';
import Modal from '../components/ui/Modal';
import PageHeader from '../components/ui/PageHeader';
import Spinner from '../components/ui/Spinner';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useAsync } from '../hooks/useAsync';
import { createStudent, getStudents } from '../services/studentService';
import { ROLES, STUDENT_ID_PATTERN } from '../utils/constants';
import { getErrorMessage } from '../utils/errors';

function NewStudentDialog({ open, onClose, onCreated }) {
  const toast = useToast();
  const [values, setValues] = useState({ name: '', rollNumber: '', email: '' });
  const [busy, setBusy] = useState(false);
  const change = (key) => (event) => setValues((current) => ({ ...current, [key]: event.target.value }));
  const idError = values.rollNumber.trim() && !STUDENT_ID_PATTERN.test(values.rollNumber.trim()) ? 'Use letters, numbers, dots, hyphens or underscores, up to 64 characters.' : undefined;

  const submit = async (event) => {
    event.preventDefault();
    setBusy(true);
    try {
      const student = await createStudent({
        name: values.name.trim(),
        rollNumber: values.rollNumber.trim(),
        ...(values.email.trim() && { email: values.email.trim() }),
      });
      toast.success('Student added.');
      setValues({ name: '', rollNumber: '', email: '' });
      onCreated(student);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title="Add student" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <TextInput label="Full name" value={values.name} onChange={change('name')} required />
        <TextInput label="Roll number" value={values.rollNumber} onChange={change('rollNumber')} error={idError} required />
        <TextInput label="Email" type="email" value={values.email} onChange={change('email')} />
        <div className="flex justify-end gap-2 pt-2">
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" loading={busy} disabled={!values.name.trim() || !values.rollNumber.trim() || Boolean(idError)}>
            Add student
          </Button>
        </div>
      </form>
    </Modal>
  );
}

export default function StudentsPage() {
  const { user } = useAuth();
  const isAdmin = user.role === ROLES.ADMIN;
  const { data, loading, error, reload } = useAsync(getStudents);
  const [query, setQuery] = useState('');
  const [creating, setCreating] = useState(false);

  const rows = useMemo(() => {
    const term = query.trim().toLowerCase();
    return (data ?? []).filter(
      (student) =>
        !term || student.name.toLowerCase().includes(term) || String(student.rollNumber).toLowerCase().includes(term),
    );
  }, [data, query]);

  const header = (
    <PageHeader
      title="Students"
      description={isAdmin ? 'Add students and enroll their faces.' : 'Students in your courses.'}
      actions={
        isAdmin && (
          <Button variant="primary" icon={Plus} onClick={() => setCreating(true)}>
            Add student
          </Button>
        )
      }
    />
  );

  if (loading) {
    return (
      <>
        {header}
        <Spinner label="Loading students" />
      </>
    );
  }
  if (error) {
    return (
      <>
        {header}
        <ErrorState message={error} onRetry={reload} />
      </>
    );
  }

  return (
    <>
      {header}
      <Card padded={false}>
        <div className="border-b border-line px-4 py-3">
          <SearchInput value={query} onChange={setQuery} placeholder="Search by name or roll number" label="Search students" />
        </div>
        {rows.length === 0 ? (
          <EmptyState
            icon={Users}
            title={data.length ? 'No students match your search' : 'No students yet'}
            description={data.length ? undefined : isAdmin ? 'Add a student to begin.' : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-left text-sm">
              <caption className="sr-only">Students</caption>
              <thead>
                <tr className="border-b border-line bg-paper text-xs font-semibold text-muted">
                  <th scope="col" className="px-4 py-2">Roll Number</th>
                  <th scope="col" className="px-4 py-2">Name</th>
                  <th scope="col" className="px-4 py-2">Email</th>
                  <th scope="col" className="px-4 py-2">Face photographs</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((student) => (
                  <tr key={student.id} className="border-b border-line last:border-b-0 hover:bg-paper/70">
                    <td className="px-4 py-3 tabular-nums">{student.rollNumber}</td>
                    <td className="px-4 py-3 font-semibold">
                      <Link to={`/students/${student.id}`} className="text-primary hover:underline">
                        {student.name}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-muted">{student.email}</td>
                    <td className="px-4 py-3 tabular-nums">
                      {student.faceCount > 0 ? (
                        student.faceCount
                      ) : (
                        <Badge tone="warn" icon={AlertTriangle}>None, cannot be recognized</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      <NewStudentDialog
        open={creating}
        onClose={() => setCreating(false)}
        onCreated={() => {
          setCreating(false);
          reload();
        }}
      />
    </>
  );
}
