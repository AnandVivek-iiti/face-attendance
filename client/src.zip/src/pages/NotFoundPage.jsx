import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <h1 className="font-serif text-3xl font-bold text-ink">Page not found</h1>
      <p className="mt-2 text-sm text-muted">The address does not match any page.</p>
      <Link to="/dashboard" className="mt-4 text-sm font-semibold text-primary hover:underline">
        Go to dashboard
      </Link>
    </div>
  );
}
