import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import {
  BookOpen,
  Camera,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  ScanFace,
  User,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ROLES } from '../utils/constants';
import { initials } from '../utils/format';

const navByRole = {
  [ROLES.PROFESSOR]: [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/attendance/new', label: 'Take attendance', icon: Camera },
    { to: '/courses', label: 'Courses', icon: BookOpen },
    { to: '/attendance/history', label: 'Attendance history', icon: History },
    { to: '/students', label: 'Students', icon: Users },
    { to: '/profile', label: 'Profile', icon: User },
  ],
  [ROLES.ADMIN]: [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/courses', label: 'Courses', icon: BookOpen },
    { to: '/students', label: 'Students', icon: Users },
    { to: '/attendance/history', label: 'Attendance history', icon: History },
    { to: '/profile', label: 'Profile', icon: User },
  ],
  [ROLES.STUDENT]: [
    { to: '/dashboard', label: 'My attendance', icon: LayoutDashboard },
    { to: '/attendance/history', label: 'History', icon: History },
    { to: '/profile', label: 'Profile', icon: User },
  ],
};

function NavItems({ items, onNavigate }) {
  return (
    <nav aria-label="Main" className="flex flex-col gap-0.5">
      {items.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          end={to === '/dashboard'}
          onClick={onNavigate}
          className={({ isActive }) =>
            `flex items-center gap-2.5 rounded-ctl px-3 py-2 text-sm font-semibold ${
              isActive ? 'bg-primary text-white' : 'text-ink hover:bg-paper'
            }`
          }
        >
          <Icon size={16} aria-hidden="true" />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}

function Sidebar({ items, user, onSignOut, onNavigate }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 py-4">
        <span className="flex h-8 w-8 items-center justify-center rounded-ctl bg-primary text-white">
          <ScanFace size={18} aria-hidden="true" />
        </span>
        <span className="font-serif text-lg font-bold text-ink">Face Attendance</span>
      </div>
      <div className="flex-1 px-3">
        <NavItems items={items} onNavigate={onNavigate} />
      </div>
      <div className="border-t border-line p-3">
        <div className="flex items-center gap-2.5 px-1 pb-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-soft text-xs font-bold text-primary">
            {initials(user.name) || '?'}
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-ink">{user.name || user.email}</p>
            <p className="text-xs capitalize text-muted">{user.role}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onSignOut}
          className="flex w-full items-center gap-2 rounded-ctl px-3 py-2 text-sm font-semibold text-ink hover:bg-paper"
        >
          <LogOut size={16} aria-hidden="true" />
          Sign out
        </button>
      </div>
    </div>
  );
}

export default function AppLayout() {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const items = navByRole[user.role] ?? navByRole[ROLES.STUDENT];

  return (
    <div className="min-h-screen bg-paper lg:flex">
      <aside className="hidden w-56 shrink-0 border-r border-line bg-white lg:block">
        <div className="sticky top-0 h-screen">
          <Sidebar items={items} user={user} onSignOut={signOut} />
        </div>
      </aside>

      <header className="flex items-center justify-between border-b border-line bg-white px-4 py-3 lg:hidden">
        <span className="font-serif text-lg font-bold text-ink">Face Attendance</span>
        <button type="button" onClick={() => setOpen(true)} aria-label="Open menu" className="rounded p-1 text-ink">
          <Menu size={22} />
        </button>
      </header>

      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} aria-hidden="true" />
          <div className="absolute inset-y-0 left-0 w-64 bg-white shadow-lg">
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
              className="absolute right-2 top-3 rounded p-1 text-muted"
            >
              <X size={18} />
            </button>
            <Sidebar items={items} user={user} onSignOut={signOut} onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}

      <main className="min-w-0 flex-1 px-4 py-6 lg:px-8">
        <Outlet />
      </main>
    </div>
  );
}
